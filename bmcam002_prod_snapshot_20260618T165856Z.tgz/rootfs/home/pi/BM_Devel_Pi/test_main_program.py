# # filename: test_main_program.py
# # description: test the functionality for the camera module

import os
import csv
import time
import subprocess  # Fix for missing import
from datetime import datetime, timezone
from process_image import capture_image, compress_and_send_image, get_cpu_temperature, get_file_size

# Time window in military format (5:00 AM to 11:59 PM)
time_start = (00, 00)  
time_end = (23, 59)
log_file = "/home/pi/BM_Devel_Pi/camera_log.csv"

# Debug flag to control printing of messages to the terminal
debug = True

def debug_print(message):
	"""Helper function to print debug messages if debugging is enabled."""
	if debug:
		print(f"[DEBUG] {message}")

def get_rtc_time():
	"""Retrieve the current time from the RTC."""
	try:
		result = subprocess.run(["sudo", "hwclock", "-r"], capture_output=True, text=True)
		rtc_time_str = result.stdout.strip()
		rtc_time = datetime.strptime(rtc_time_str.split('.')[0], '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
		debug_print(f"RTC Time: {rtc_time}")
		return rtc_time
	except Exception as e:
		debug_print(f"Error reading RTC time: {e}")
		return None

def is_within_time_window(rtc_time, time_start, time_end):
	"""Check if the current RTC time is within the specified time window."""
	start_time = datetime(rtc_time.year, rtc_time.month, rtc_time.day, time_start[0], time_start[1]).time()
	end_time = datetime(rtc_time.year, rtc_time.month, rtc_time.day, time_end[0], time_end[1]).time()
	is_within = start_time <= rtc_time.time() < end_time
	debug_print(f"Time is within window: {is_within}")
	return is_within

def log_message(rtc_time, within_window, image_filename, file_size_before, compression_quality, cpu_temp, file_size_after=None, delta_time=None):
	"""Log details to the CSV."""
	file_exists = os.path.isfile(log_file)

	with open(log_file, 'a', newline='') as file:
		writer = csv.writer(file)

		if not file_exists:
			writer.writerow([
				"RTC Timestamp", "Within Time Window", "Image Filename",
				"File Size Before (bytes)", "File Size After (bytes)", 
				"Compression Quality", "CPU Temperature (C)", "Execution Time (minutes)"
			])

		# Handle CPU temperature if it's a string or float
		if isinstance(cpu_temp, float):
			cpu_temp_str = f"{cpu_temp:.2f}°C"
		else:
			cpu_temp_str = cpu_temp  # Use the string directly if it's not a float

		row = [
			rtc_time.strftime('%Y-%m-%dT%H:%M:%S%z'), within_window,
			image_filename, f"{file_size_before} bytes", 
			f"{file_size_after if file_size_after else 'Pending'} bytes",
			compression_quality, cpu_temp_str, 
			f"{delta_time:.2f} min" if delta_time else "Pending"
		]

		writer.writerow(row)
		debug_print(f"Logged entry for image: {image_filename}")

def main():
	"""Main function to orchestrate the camera workflow."""
	start_time = time.time()

	rtc_time = get_rtc_time()
	if rtc_time:
		within_window = is_within_time_window(rtc_time, time_start, time_end)
		
		if within_window:
			image_path = capture_image(resolution_key="VGA")

			file_size_before = get_file_size(image_path)
			cpu_temp = get_cpu_temperature()

			log_message(rtc_time, "yes", os.path.basename(image_path), file_size_before, 50, cpu_temp)

			compress_and_send_image(image_path)

			file_size_after = get_file_size(image_path)
		else:
			image_path = "no picture"
			file_size_before = 0
			file_size_after = 0
			cpu_temp = get_cpu_temperature()
			log_message(rtc_time, "no", image_path, file_size_before, 50, cpu_temp)

		end_time = time.time()
		delta_time = (end_time - start_time) / 60

		log_message(rtc_time, "yes", os.path.basename(image_path), file_size_before, 50, cpu_temp, file_size_after, delta_time)
	else:
		log_message(datetime.now(timezone.utc), "no", "Failed to read RTC time", 0, 50, "N/A")

if __name__ == "__main__":
	main()
