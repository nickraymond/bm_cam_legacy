# # # filename: process_image.py
# # # description: this is same as split_and_send.py but refactored to be modular + call from other scripts
# 
# import cv2
# import os
# import shutil
# import base64
# import time
# from bm_serial import BristlemouthSerial
# 
# buffer_size = 300
# 
# def encode_to_base64(binary_data):
# 	base64_encoded_data = base64.b64encode(binary_data)
# 	return base64_encoded_data.decode('ascii')
# 
# def split_image(image, buffer_directory, compression_quality):
# 	"""
# 	Splits the image into base64-encoded buffers and saves them as text files.
# 
# 	Parameters:
# 	- image: The image data loaded by OpenCV.
# 	- buffer_directory: The directory to save the buffer files.
# 	- compression_quality: JPEG compression quality (0-100). Lower values reduce size but also decrease quality.
# 	  Example: compression_quality=10 will result in a smaller file size but lower image quality. 
# 	  compression_quality=100 will preserve more details but result in a larger file size.
# 	"""
# 	# Cleanup old buffers
# 	if os.path.exists(buffer_directory):
# 		shutil.rmtree(buffer_directory)
# 		print("Deleted buffers dir")
# 	
# 	# Create new buffers directory
# 	os.makedirs(buffer_directory, exist_ok=True)
# 	print("Created buffers dir")
# 	
# 	# Encode image to jpeg with specified compression quality
# 	retval, buffer = cv2.imencode('.jpg', image, [int(cv2.IMWRITE_JPEG_QUALITY), compression_quality])
# 	print(f"length of buffer: {len(buffer)}")
# 
# 	if retval:
# 		# Convert buffer to a bytes object and encode in base64
# 		base64_data = base64.b64encode(buffer).decode("ascii")
# 		print(f"length of base 64: {len(base64_data)}")
# 		print("Success encoding image")
# 	else:
# 		raise ValueError("Failed to encode image")
# 
# 	file_length = len(base64_data)
# 
# 	buffer_number = 0
# 	while (buffer_number * buffer_size < file_length):
# 		start_pos = buffer_number * buffer_size
# 		current_buffer = base64_data[start_pos:start_pos + buffer_size]
# 
# 		# Write the buffer to its own text file
# 		path = os.path.join(buffer_directory, f"split_{buffer_number}.txt")
# 		with open(path, 'w') as buffer_file:
# 			buffer_file.write(current_buffer)
# 		
# 		buffer_number += 1
# 
# 	print(f"Saved {buffer_number} buffer txt files.")
# 
# def send_buffers(buffer_directory, capture_directory):
# 	"""
# 	Sends the buffer files over UART using the BristlemouthSerial class.
# 	"""
# 	# Find the number of buffer files generated
# 	if os.path.exists(buffer_directory):
# 		# List everything in the directory
# 		files = os.listdir(buffer_directory)
# 		num_buffers = len(files)
# 		print(f"{num_buffers} buffers found")
# 
# 	# Get the index label for this image
# 	if os.path.exists(capture_directory):
# 		# List everything in the directory
# 		files = os.listdir(capture_directory)
# 		this_capture_index = len(files) - 1
# 		print(f"Working with image index {this_capture_index}")
# 
# 	# Initialize the BristlemouthSerial object
# 	bm = BristlemouthSerial()
# 
# 	try:
# 		start_msg = f"<START IMG {this_capture_index}> length: {num_buffers}\n"
# 		bm.spotter_tx(start_msg.encode('ascii'))
# 		print(f'Sent {start_msg}')
# 		time.sleep(5)  # wait to ensure the start tag sends fully
# 
# 		for i in range(num_buffers):
# 			buffer_path = os.path.join(buffer_directory, f"split_{i}.txt")
# 			with open(buffer_path, 'r') as buffer_file:
# 				buffer_data = buffer_file.read()
# 			buffer_to_send = f"<I{i}>" + buffer_data + '\n'
# 			bm.spotter_tx(buffer_to_send.encode('ascii'))
# 			print(f'Sent buffer {i} of {num_buffers}')
# 			time.sleep(5)
# 
# 		time.sleep(10)  # wait to ensure all send before the end tag
# 		end_msg = f"<END IMG {this_capture_index}>\n"
# 		bm.spotter_tx(end_msg.encode('ascii'))
# 		print(f'Sent {end_msg}')
# 	except Exception as e:
# 		print("An exception occurred:", e)
# 	finally:
# 		bm.uart.close()
# 
# def process_image(image_path, buffer_directory, capture_directory, compression_quality=10):
# 	"""
# 	Main function to process the image by splitting and sending it.
# 
# 	Parameters:
# 	- image_path: The absolute path to the image file.
# 	- buffer_directory: The directory to store the buffer files.
# 	- capture_directory: The directory where the images are stored.
# 	- compression_quality: JPEG compression quality (0-100). Lower values reduce size but also decrease quality.
# 	"""
# 	img = cv2.imread(image_path)
# 	if img is None:
# 		raise ValueError("Image is empty or not loaded correctly")
# 	
# 	split_image(img, buffer_directory, compression_quality)
# 	send_buffers(buffer_directory, capture_directory)
# 
# # Example usage:
# # process_image("/home/pi/BM_Devel_Pi/capture_archive/image_VGA.jpg", "/home/pi/BM_Devel_Pi/buffers/", "/home/pi/BM_Devel_Pi/capture_archive", compression_quality=20)


# NEW - added file name to the start message at 9:19am Sept 15th
# filename: process_image.py
# description: this is same as split_and_send.py but refactored to be modular + call from other scripts
# 
# import cv2
# import os
# import shutil
# import base64
# import time
# import datetime
# from bm_serial import BristlemouthSerial
# 
# buffer_size = 300
# 
# def encode_to_base64(binary_data):
# 	base64_encoded_data = base64.b64encode(binary_data)
# 	return base64_encoded_data.decode('ascii')
# 
# def split_image(image, buffer_directory, compression_quality):
# 	"""
# 	Splits the image into base64-encoded buffers and saves them as text files.
# 
# 	Parameters:
# 	- image: The image data loaded by OpenCV.
# 	- buffer_directory: The directory to save the buffer files.
# 	- compression_quality: JPEG compression quality (0-100). Lower values reduce size but also decrease quality.
# 	Example: compression_quality=10 will result in a smaller file size but lower image quality. 
# 	compression_quality=100 will preserve more details but result in a larger file size.
# 	"""
# 	# Cleanup old buffers
# 	if os.path.exists(buffer_directory):
# 		shutil.rmtree(buffer_directory)
# 		print("Deleted buffers dir")
# 	
# 	# Create new buffers directory
# 	os.makedirs(buffer_directory, exist_ok=True)
# 	print("Created buffers dir")
# 	
# 	# Encode image to jpeg with specified compression quality
# 	retval, buffer = cv2.imencode('.jpg', image, [int(cv2.IMWRITE_JPEG_QUALITY), compression_quality])
# 	print(f"length of buffer: {len(buffer)}")
# 
# 	if retval:
# 		# Convert buffer to a bytes object and encode in base64
# 		base64_data = base64.b64encode(buffer).decode("ascii")
# 		print(f"length of base 64: {len(base64_data)}")
# 		print("Success encoding image")
# 	else:
# 		raise ValueError("Failed to encode image")
# 
# 	file_length = len(base64_data)
# 
# 	buffer_number = 0
# 	while (buffer_number * buffer_size < file_length):
# 		start_pos = buffer_number * buffer_size
# 		current_buffer = base64_data[start_pos:start_pos + buffer_size]
# 
# 		# Write the buffer to its own text file
# 		path = os.path.join(buffer_directory, f"split_{buffer_number}.txt")
# 		with open(path, 'w') as buffer_file:
# 			buffer_file.write(current_buffer)
# 		
# 		buffer_number += 1
# 
# 	print(f"Saved {buffer_number} buffer txt files.")
# 
# def send_buffers(buffer_directory, capture_directory):
# 	"""
# 	Sends the buffer files over UART using the BristlemouthSerial class.
# 	Adds filename and timestamp to the start message.
# 	"""
# 	# Find the number of buffer files generated
# 	if os.path.exists(buffer_directory):
# 		# List everything in the directory
# 		files = os.listdir(buffer_directory)
# 		num_buffers = len(files)
# 		print(f"{num_buffers} buffers found")
# 
# 	# Get the index label for this image
# 	if os.path.exists(capture_directory):
# 		# List everything in the directory
# 		files = os.listdir(capture_directory)
# 		this_capture_index = len(files) - 1
# 		print(f"Working with image index {this_capture_index}")
# 
# 	# Initialize the BristlemouthSerial object
# 	bm = BristlemouthSerial()
# 
# 	try:
# 		# Get the current timestamp
# 		current_timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
# 
# 		# Add filename and timestamp to the start message
# 		start_msg = f"<START IMG {this_capture_index}> filename: image_{this_capture_index}_VGA.jpg, timestamp: {current_timestamp}, length: {num_buffers}\n"
# 		bm.spotter_tx(start_msg.encode('ascii'))
# 		print(f'Sent {start_msg}')
# 		time.sleep(5)  # Wait to ensure the start tag sends fully
# 
# 		# Send each buffer
# 		for i in range(num_buffers):
# 			buffer_path = os.path.join(buffer_directory, f"split_{i}.txt")
# 			with open(buffer_path, 'r') as buffer_file:
# 				buffer_data = buffer_file.read()
# 			buffer_to_send = f"<I{i}>" + buffer_data + '\n'
# 			bm.spotter_tx(buffer_to_send.encode('ascii'))
# 			print(f'Sent buffer {i} of {num_buffers}')
# 			time.sleep(5)
# 
# 		# Wait to ensure all send before the end tag
# 		time.sleep(10)
# 		end_msg = f"<END IMG {this_capture_index}>\n"
# 		bm.spotter_tx(end_msg.encode('ascii'))
# 		print(f'Sent {end_msg}')
# 	except Exception as e:
# 		print("An exception occurred:", e)
# 	finally:
# 		bm.uart.close()
# 
# def process_image(image_path, buffer_directory, capture_directory, compression_quality=10):
# 	"""
# 	Main function to process the image by splitting and sending it.
# 
# 	Parameters:
# 	- image_path: The absolute path to the image file.
# 	- buffer_directory: The directory to store the buffer files.
# 	- capture_directory: The directory where the images are stored.
# 	- compression_quality: JPEG compression quality (0-100). Lower values reduce size but also decrease quality.
# 	"""
# 	img = cv2.imread(image_path)
# 	if img is None:
# 		raise ValueError("Image is empty or not loaded correctly")
# 	
# 	split_image(img, buffer_directory, compression_quality)
# 	send_buffers(buffer_directory, capture_directory)
# 
# # Example usage:
# # process_image("/home/pi/BM_Devel_Pi/capture_archive/image_VGA.jpg", "/home/pi/BM_Devel_Pi/buffers/", "/home/pi/BM_Devel_Pi/capture_archive", compression_quality=20)
import cv2
import os
import shutil
import base64
import time
from datetime import datetime, timezone
from picamera2 import Picamera2
import subprocess  # Fix for missing import
from bm_serial import BristlemouthSerial

buffer_size = 300

# Debug flag to control printing of messages to the terminal
debug = True

def debug_print(message):
	"""Helper function to print debug messages if debugging is enabled."""
	if debug:
		print(f"[DEBUG] {message}")

# Hard-coded image directory path
IMAGE_DIRECTORY = "/home/pi/BM_Devel_Pi/capture_archive"

# Define the available resolution options
RESOLUTIONS = {
	"12MP": (4056, 3040),
	"8MP": (3264, 2448),
	"5MP": (2592, 1944),
	"4MP": (2464, 1848),
	"1080p": (1920, 1080),
	"720p": (1280, 720),
	"VGA": (640, 480)
}

def validate_resolution(resolution_key):
	"""Validate the resolution key and return the corresponding resolution."""
	if resolution_key not in RESOLUTIONS:
		raise ValueError(f"Invalid resolution key. Choose from: {', '.join(RESOLUTIONS.keys())}")
	return RESOLUTIONS[resolution_key]

def generate_filename():
	"""Generate a filename in the format of ISO 8601 timestamp + image.jpg."""
	current_timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
	return f"{current_timestamp}_image.jpg"

def capture_image(resolution_key="720p", directory_path=IMAGE_DIRECTORY):
	"""Capture an image with the specified resolution and save it in the directory."""
	resolution = validate_resolution(resolution_key)

	# Initialize the camera
	picam2 = Picamera2()

	# Set the configuration with the chosen resolution
	config = picam2.create_still_configuration(main={"size": resolution})

	# Apply the configuration
	picam2.configure(config)

	# Start the camera
	picam2.start()

	# Allow the camera to warm up
	time.sleep(2)

	# Generate the filename and construct the full image path
	image_filename = generate_filename()
	image_path = os.path.join(directory_path, image_filename)

	# Ensure the directory exists
	if not os.path.exists(directory_path):
		os.makedirs(directory_path)

	# Capture the image and save it to the specified path
	picam2.capture_file(image_path)
	print(f"Image captured and saved as '{image_path}'")

	# Stop the camera
	picam2.stop()

	return image_path  # Return the path for further use

def encode_to_base64(binary_data):
	return base64.b64encode(binary_data).decode('ascii')

def get_cpu_temperature():
	"""Get the Raspberry Pi's CPU temperature."""
	result = subprocess.run(["vcgencmd", "measure_temp"], capture_output=True, text=True)
	temp_str = result.stdout.strip().replace("temp=", "").replace("'C", "")
	return float(temp_str)

def get_file_size(file_path):
	"""Get the file size of a given file in bytes."""
	if os.path.exists(file_path):
		return os.path.getsize(file_path)
	return 0

def split_image(image, buffer_directory, compression_quality):
	"""Splits the image into base64-encoded buffers."""
	if os.path.exists(buffer_directory):
		shutil.rmtree(buffer_directory)
		debug_print("Deleted buffers dir")

	os.makedirs(buffer_directory, exist_ok=True)
	debug_print("Created buffers dir")

	retval, buffer = cv2.imencode('.jpg', image, [int(cv2.IMWRITE_JPEG_QUALITY), compression_quality])
	if not retval:
		raise ValueError("Failed to encode image")

	base64_data = base64.b64encode(buffer).decode("ascii")
	file_length = len(base64_data)

	buffer_number = 0
	while buffer_number * buffer_size < file_length:
		start_pos = buffer_number * buffer_size
		current_buffer = base64_data[start_pos:start_pos + buffer_size]
		buffer_path = os.path.join(buffer_directory, f"split_{buffer_number}.txt")
		with open(buffer_path, 'w') as buffer_file:
			buffer_file.write(current_buffer)
		buffer_number += 1

	debug_print(f"Saved {buffer_number} buffer txt files.")

def send_buffers(buffer_directory):
	"""Sends the buffer files over UART, with debug messages showing progress."""
	files = os.listdir(buffer_directory)
	num_buffers = len(files)

	bm = BristlemouthSerial()
	current_timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
	image_filename = generate_filename()

	# Add debug messages for each step if debugging is enabled
	debug_print(f"Starting transmission of image: {image_filename} with {num_buffers} buffers.")

	start_msg = f"<START IMG> filename: {image_filename}, timestamp: {current_timestamp}, length: {num_buffers}\n"
	bm.spotter_tx(start_msg.encode('ascii'))
	time.sleep(5)

	for i in range(num_buffers):
		buffer_path = os.path.join(buffer_directory, f"split_{i}.txt")
		with open(buffer_path, 'r') as buffer_file:
			buffer_data = buffer_file.read()
		
		buffer_to_send = f"<I{i}>{buffer_data}\n"
		bm.spotter_tx(buffer_to_send.encode('ascii'))

		# Debug message for each buffer being sent
		debug_print(f"Sent buffer {i+1} of {num_buffers}")

		time.sleep(5)

	end_msg = f"<END IMG>\n"
	bm.spotter_tx(end_msg.encode('ascii'))
	debug_print(f"Finished transmission of image: {image_filename}")
	time.sleep(10)
	bm.uart.close()

def compress_and_send_image(image_path, compression_quality=50):
	"""Compress and send the image."""
	buffer_directory = "/home/pi/BM_Devel_Pi/buffers/"

	img = cv2.imread(image_path)
	split_image(img, buffer_directory, compression_quality)
	send_buffers(buffer_directory)
