import sys
import time
import bm_serial
from bm_serial import BristlemouthSerial

print("Using bm_serial from:", bm_serial.__file__, flush=True)

sizes = [300, 500, 700, 850, 900, 950, 990]

bm = BristlemouthSerial()

for size in sizes:
    payload = (f"nereus-test-size-{size},".encode() + b"A" * size)[:size]
    print(f"\n===== SENDING payload_len={len(payload)} =====", flush=True)
    bm.spotter_tx(payload)
    print(f"===== SENT payload_len={len(payload)} =====", flush=True)
    time.sleep(12)
